# TODO — OCodejs Brand Guidelines Website

## Brand Guidelines website
- [x] Trang tổng quan responsive giới thiệu hệ thống nhận diện OCodejs và điều hướng tới từng nội dung hướng dẫn.
- [x] Trình bày logo O tròn, lockup OCODEJS, biến thể và quy tắc sử dụng đúng.
- [x] Minh họa khoảng an toàn và kích thước hiển thị tối thiểu.
- [x] Hiển thị bảng màu thương hiệu kèm mã màu và mẫu màu trực quan.
- [x] Giới thiệu gradient kim loại với thông số và ví dụ áp dụng.
- [x] Trình bày hệ thống kiểu chữ, phân cấp typography và ví dụ sử dụng.
- [x] Mô tả nguyên tắc giao diện thương hiệu qua thành phần và ví dụ minh họa.
- [x] Tổng hợp các trường hợp không được sử dụng logo.
- [x] Showcase mockup thực tế trên áo đồng phục, danh thiếp và giao diện app.
- [x] Đảm bảo responsive tốt trên desktop và mobile, có route manifest và metadata phù hợp.
